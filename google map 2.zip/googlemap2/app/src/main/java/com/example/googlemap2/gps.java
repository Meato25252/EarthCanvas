//package com.example.googlemap2;
//
//import android.Manifest;
//import android.content.Context;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.location.Location;
//import android.location.LocationListener;
//import android.location.LocationManager;
//import android.provider.Settings;
//import android.util.Log;
//import android.widget.Toast;
//
//import androidx.activity.result.ActivityResultLauncher;
//import androidx.activity.result.contract.ActivityResultContracts;
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//
//public class gps extends AppCompatActivity implements LocationListener {
//
//    LocationManager locationManager;
//    double num1;
//    double num2;
//
//    double numTotal;
//
//    // パーミッション要求用のActivityResultLauncherを定義
//    private final ActivityResultLauncher<String>
//            requestPermissionLauncher = registerForActivityResult(
//            new ActivityResultContracts.RequestPermission(),
//            isGranted -> {
//                if (isGranted) {
//                    // パーミッションが許可された場合、位置情報取得を開始
//                    locationStart();
//                } else {
//                    // パーミッションが拒否された場合の処理
//                    Toast toast = Toast.makeText(this,
//                            "これ以上できません", Toast.LENGTH_SHORT);
//                    toast.show();
//                }
//            });
//
//
//    gps(Context context) {
//        System.out.println(context);
//
////         ACCESS_FINE_LOCATIONのパーミッションをチェック
//        if (ActivityCompat.checkSelfPermission(context,
//                Manifest.permission.ACCESS_FINE_LOCATION)
//                != PackageManager.PERMISSION_GRANTED) {
//
//            // パーミッションが許可されていない場合、要求
//            requestPermissionLauncher.launch(
//                    Manifest.permission.ACCESS_FINE_LOCATION);
//        } else {
////             パーミッションが許可されている場合、位置情報取得を開始
//
//
//            locationStart();
//
//
//        }
//    }
//
//
//    public void locationStart(){
//        Log.d("debug", "locationStart()");
//
//        // LocationManager インスタンス生成
//        locationManager =
//                (LocationManager) getSystemService(LOCATION_SERVICE);
//
//        if (locationManager != null && locationManager.isProviderEnabled(
//                LocationManager.GPS_PROVIDER)) {
//
//            // GPSが有効の場合の処理
//            Log.d("debug", "location manager Enabled");
//        } else {
//            // GPSが無効の場合、GPS設定画面を開く
//            Intent settingsIntent =
//                    new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//            startActivity(settingsIntent);
//            Log.d("debug", "not gpsEnable, startActivity");
//        }
//
//        // ACCESS_FINE_LOCATIONのパーミッションが付与されているかチェック
//        if (ContextCompat.checkSelfPermission(this,
//                android.Manifest.permission.ACCESS_FINE_LOCATION) !=
//                PackageManager.PERMISSION_GRANTED) {
//
//            // ACCESS_FINE_LOCATIONのパーミッションが付与されているかチェック
//            ActivityCompat.requestPermissions(this,
//                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,}, 1000);
//
//            Log.d("debug", "checkSelfPermission false");
//
//        }
//        // 位置情報の更新をリクエスト
//        //50m端末が移動するかつ、3秒ごとに位置情報が更新される
//        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
//
//                3000, 50, this);
//
//
//    }
//
//
//    @Override
//    public void onLocationChanged (Location location){
////     位置情報が変更された時の処理
//        // 緯度の表示
////    String str1 = "Latitude:"+location.getLatitude();
//        num1 = location.getLatitude();
//
//        // 経度の表示
//        num2 = location.getLongitude();
////    String str2 = "Longitude:"+location.getLongitude();
//
//        numTotal = num1 + num2;
//
//    }
//
////    public double getLocate1(){
////        return num1;
////    }
////    public double getLocate2(){
////        return num2;
////    }
//}
//
